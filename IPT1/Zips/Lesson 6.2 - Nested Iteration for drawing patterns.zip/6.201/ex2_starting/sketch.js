

function setup() 
{
    createCanvas(800,800);
}

function draw() 
{

    background(0);



    for(var i = 0; i < 10; i++)
    {
        fill(255,0,255);
        ellipse(50 + i * 50, 50,50,50);
    }
    

 
}
