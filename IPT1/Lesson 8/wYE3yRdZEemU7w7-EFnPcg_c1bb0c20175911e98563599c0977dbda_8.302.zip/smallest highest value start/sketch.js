var numArray = [];
function setup()
{
    for(var i = 0; i < 100; i++){
        numArray.push(round(random(0, 1000)));
    }
    
    //find the smallest value in the array
    //and its index
    
}

function draw()
{
    
}


